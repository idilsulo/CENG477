
Note:

For box_maker explanation image, vertex 5 should be vertex 6 and vertex 6 should be vertex 5.

Example calls:

>_ python box_maker.py -10 10 10 30 10 5 0

>_ python cone_maker.py 0 0 5 10 10 0.25 0
>_ python cone_maker.py 0 0 5 10 10 0.25 0 "255|0|255" "0|23|155" "50|140|50" "0|255|255"

>_ python star_maker.py 0 0 20 10 0 10 0
